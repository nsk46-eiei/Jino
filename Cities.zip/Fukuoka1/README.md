Fukuoka

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 1.0 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 0.666666 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1.5ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 0.5 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 0.4 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2.5ps.rou.xml

Bangkok

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 2.0849984 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 1.389999 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1.5ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 1.0424992 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 0.8339993 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2.5ps.rou.xml

Singapore

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 5.1985131 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 3.4656755 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_1.5ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 2.5992565 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2ps.rou.xml

python3 randomTrips.py -n osm.net.xml.gz -b 0 -e 3600 \--period 2.0794052 --seed 42 --validate \--trip-attributes 'departLane="best" departPos="random" departSpeed="max"' \-o trips_dens_2.5ps.rou.xml
